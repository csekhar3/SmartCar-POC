import { HttpClient } from '@angular/common/http';
import { Component, NgZone, OnInit } from '@angular/core';
import { VehicleVIN } from '../model/vin_detail';
import { ApicallService } from '../service/apicall.service';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { ModalComponentComponent } from '../modal-component/modal-component.component';
import { DataToSub } from '../model/data_to_subscribe';
import { ViewChild } from '@angular/core';
import { ElementRef } from '@angular/core';
import * as Smartcar from '@smartcar/auth';

@Component({
  selector: 'app-form-page',
  templateUrl: './form-page.component.html',
  styleUrls: ['./form-page.component.scss']
})
export class FormPageComponent implements OnInit {
  spinnerRef=undefined;
  confirmationRef=undefined;
  vin = new VehicleVIN();
  dataToSub = new DataToSub();
  showVIN=true;
  showScope=false;
  zone=undefined;
  client: any;
  codefromURL: any;
  constructor(public http: HttpClient, private apiService: ApicallService,public dialog: MatDialog,private _ngZone: NgZone) { 
    this.zone=_ngZone;
  }

  ngOnInit() {
    this.client = new Smartcar({
      clientId: '50758431-69da-4e4c-9667-dca821fd6a58',
      redirectUri: 'http://localhost:4210/thank-you',
      scope: ['read_odometer','read_vehicle_info'],
      onComplete: function(err, code) {
        if (err) {
          // handle errors from Connect (i.e. user denies access)
        }
        // handle the returned code by sending it to your back-end server
        console.log(code);
        // if(code!=undefined){
        //   document.getElementById("submitAction").setAttribute("data-user-id", code);
        //   document.getElementById("userId").value=code;
        // }
      },
      testMode: true
    });

    console.log(window.location.href);
    
    
  }

  checkCompatible(){
    if(this.vin.VIN_NUMBER.length==0){
      alert("Enter Vehicle Number");
    }else{
      this.openDialog();
      this.apiService.checkCompatible(this.vin).subscribe((res)=>{
        res=JSON.parse(JSON.stringify(res));
        if(res.compatible){
          this.spinnerRef.close();
          this.openConfirmation(2,this.vin.VIN_NUMBER);
        }else{
          this.spinnerRef.close();
          this.openConfirmation(3,this.vin.VIN_NUMBER);
        }
        
      });
    }
  }

  openDialog(): void {
     this.spinnerRef = this.dialog.open(ModalComponentComponent, {
      width: '150px',
      height: '150px',
      data: { type: 1, dataValue: {} }
    });
  }
  

  openConfirmation(status:number,deviceNo:string ): void {
    this.confirmationRef = this.dialog.open(ModalComponentComponent, {
     width: '550px',
     height: '250px',
     data: { type: status, dataValue: { deviceNo: deviceNo} }
   });
   this.confirmationRef.afterClosed().subscribe(result => {
      if(result.data){
        this.showScope=true;
        this.showVIN=false;
      }
      this.vin['isApplicable']=result.data;
      this.apiService.insertVINandStatus(this.vin).subscribe((res)=>{
        console.log("Response insertVINandStatus: "+JSON.stringify(res))
        
      });
    });
  }

  submitStatus(): void {
    this.dataToSub.VIN=this.vin.VIN_NUMBER;
    //this.dataToSub.USER = this.userId.nativeElement.value;
    localStorage.setItem('dataVIn',JSON.stringify(this.dataToSub));
    console.log(JSON.stringify(this.dataToSub));

    console.log(this.client.getAuthUrl());
    window.location.href = this.client.getAuthUrl();
    this.codefromURL = window.location.href.split('=')[1].split('&')[0];
    if(this.codefromURL){
      this.checkCode(this.codefromURL);
    }
    // this.client.addClickHandler({ id: '#redirCar' });



    console.log('here')
    // this.openDialog();
    
  }

  checkCode(code){
    this.apiService.insertVINandScope(code).subscribe((res)=>{
      console.log("Response insertVINandScope: "+JSON.stringify(res))
      this.spinnerRef.close();
      this.openConfirmation(3,this.vin.VIN_NUMBER);
      this.showScope=false;
      this.showVIN=true;
    });
  }
  

}
