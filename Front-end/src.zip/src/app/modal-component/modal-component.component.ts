import { Component, EventEmitter, Inject, OnInit, Output } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-modal-component',
  templateUrl: './modal-component.component.html',
  styleUrls: ['./modal-component.component.scss']
})
export class ModalComponentComponent implements OnInit {

  type:number;
  dataValue:any;
  @Output() someEvent = new EventEmitter<string>();

  constructor(private dialogRef: MatDialogRef<ModalComponentComponent>,@Inject(MAT_DIALOG_DATA) public data: any) { 
      this.type=data.type;
      this.dataValue=data.dataValue;

  }

  ngOnInit() {
  }

  closeDialog(){
    this.dialogRef.close();
    //this.dataValue.dialogClose();
  }

  enroll(){
    
    this.dialogRef.close({data:true});
  }

}
