export class VehicleVIN {
    VIN_NUMBER:string;
}