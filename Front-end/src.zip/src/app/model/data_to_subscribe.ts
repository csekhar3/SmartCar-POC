export class DataToSub {
    USER:string;
    VIN:string;
    scope_eng_oil:boolean;
    scope_ev_battery:boolean;
    scope_ev_charge_status:boolean;
    scope_ev_charge_start_stop:boolean;
    scope_fuel_tank:boolean;
    scope_location:boolean;
    scope_lock_unlock:boolean;
    scope_odometer:boolean;
    scope_tyre:boolean;
    scope_vehicle_att:boolean;
    scope_vin:boolean;

}