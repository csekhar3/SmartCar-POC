import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { VehicleVIN } from '../model/vin_detail';
import { from, Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class ApicallService {

  constructor(private httpClient: HttpClient) { }

  checkCompatible(vin_detail: VehicleVIN) {
    return this.httpClient.post(`https://0dtqpx45pi.execute-api.us-east-2.amazonaws.com/dev/lookup`,vin_detail).
        pipe(
           map((data: any) => {
             return data;
           }), catchError( error => {
             return throwError( 'Something went wrong!' );
           })
        )
  }
  insertVINandStatus(dataCall: any) {
    return this.httpClient.post(`https://55d3cp12fi.execute-api.us-east-2.amazonaws.com/dev/insertVINandStatus`,dataCall).
        pipe(
           map((data: any) => {
             return data;
           }), catchError( error => {
             return throwError( 'Something went wrong!' );
           })
        )
  }
  insertVINandScope(dataCall: any) {
    return this.httpClient.post(`https://y4c614al8l.execute-api.us-east-2.amazonaws.com/dev/insertVINnScope`,dataCall).
        pipe(
           map((data: any) => {
             return data;
           }), catchError( error => {
             return throwError( 'Something went wrong!' );
           })
        )
  }
}
